<ul class="livestats">
    <li>
        <span class="title">Now Playing</span>
        <strong>{!! $now_playing !!}</strong>
    </li>
</ul>
