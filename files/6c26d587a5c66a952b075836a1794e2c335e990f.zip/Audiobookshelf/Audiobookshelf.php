<?php namespace App\SupportedApps\Audiobookshelf;

class Audiobookshelf extends \App\SupportedApps
{
}
