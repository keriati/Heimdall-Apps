<?php namespace App\SupportedApps\Jeedom;

class Jeedom extends \App\SupportedApps
{
}
