<?php namespace App\SupportedApps\neightn;

class N8n extends \App\SupportedApps
{
}
