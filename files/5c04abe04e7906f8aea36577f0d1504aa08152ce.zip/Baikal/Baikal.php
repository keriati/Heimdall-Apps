<?php namespace App\SupportedApps\Baikal;

class Baikal extends \App\SupportedApps
{
}
