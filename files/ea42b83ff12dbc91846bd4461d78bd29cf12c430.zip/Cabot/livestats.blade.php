<ul class="livestats">
    <li>
        <span class="title">Overall Status</span>
        <strong>{!! $count_output !!} {!! $status_output !!}</strong>
    </li>
</ul>
