<ul class="livestats">
    <li>
        <span class="title">Needed Files</span>
        <strong>{!! $needed_files !!}</strong>
    </li>
    <li>
        <span class="title">Needed Bytes</span>
        <strong>{!! $needed_bytes !!}</strong>
    </li>
</ul>
