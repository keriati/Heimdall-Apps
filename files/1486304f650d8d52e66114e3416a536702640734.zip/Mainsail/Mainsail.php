<?php namespace App\SupportedApps\Mainsail;

class Mainsail extends \App\SupportedApps
{
}
