<?php namespace App\SupportedApps\TYPO;

class TYPO3 extends \App\SupportedApps
{
}
