<?php namespace App\SupportedApps\RStudioServer;

class RStudioServer extends \App\SupportedApps
{
}
