<?php namespace App\SupportedApps\Plume;

class Plume extends \App\SupportedApps
{
}
