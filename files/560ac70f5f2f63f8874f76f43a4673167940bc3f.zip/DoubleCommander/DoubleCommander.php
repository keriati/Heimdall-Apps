<?php namespace App\SupportedApps\DoubleCommander;

class DoubleCommander extends \App\SupportedApps
{
}
